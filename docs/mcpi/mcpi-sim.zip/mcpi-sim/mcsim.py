#!/usr/bin/env python
# -*- coding: utf-8 -*-

print "Uruchamianie... poczekaj"

# import modułów minecrafta
from local.minecraft import *
from local.block import *

os.environ["USERNAME"] = "Steve"  # nazwa użytkownika
os.environ["COMPUTERNAME"] = "mykomp"  # nazwa komputera

# adres 10.10.95.64 zmień na adres Twojego Raspberry Pi
mc = Minecraft.create("10.10.95.64")  # połączenie z serwerem

# wyślij wiadomość
mc.postToChat("Hello")

# umieść blok kamienia na pozycji (x=0, y=0, z=0)
mc.setBlock(0,0,0, STONE)
