Programowanie MC Pi
###################

Katalog `local` zawiera specjalną wersję symulatora Minecraft Pi dostosowaną
do biliotek minecraft-stuff (http://www.stuffaboutcode.com/2013/11/coding-shapes-in-minecraft.html)
oraz minecraft-graphic-turtle (http://www.stuffaboutcode.com/2014/05/minecraft-graphics-turtle.html),
które również znajdują się w klatalogu.

Oryginalne pliki symulatora dostępne są w repozytorium: https://github.com/pddring/mcpi-sim.git

Katalog `mcpi` zawiera biblioteki Minecraft API dostępne rówenież w repozytorium
https://github.com/martinohanlon/mcpi.git

Plik `mcsim.py` zawiera szkielet kodu umożliwiającego uruchomienie symulatora.

Scenariusze pokazujące wykorzystanie Minecrafta Pi dostępne są pod adresem:
http://python101.readthedocs.io/pl/latest/mcpi/index.html
